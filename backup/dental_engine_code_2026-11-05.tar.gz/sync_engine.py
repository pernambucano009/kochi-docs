"""ينسخ محرك قوالب الأسنان (كود + أصول عامة بس، من غير أي صورة مريض) لجوه المنصة: studiomania/dental/engine
ويبدّل المسارات الثابتة بجذر المحرك (DENTAL_ROOT) ومفتاح Atlas بمتغير البيئة.
الاستخدام: python3 sync_engine.py"""
import os, re, shutil, py_compile

S = "/tmp/claude-0/-home-user-kochi-docs/ccdf9718-7249-5c1f-aeb5-92c8b7e649b7/scratchpad/"
DST = "/home/user/kochi-docs/studiomania/dental/engine/"
CODE = """ana/aimask.py ana/align.py ana/anim.py ana/card.py ana/gummask.py ana/teethlib.py gen/at.py
product/analysis.py product/case.py product/checks.py product/checks2.py product/elements.py product/face_teeth.py
product/intake.py product/motion.py product/needs.py product/qa_video.py product/regress.py product/run.py
tools/city_assets.py tools/derive.py tools/faithful_upscale.py tools/mouth_swap.py tools/teeth_map.py tools/view_teeth.py
tpl/T.py tpl/morph.py tpl/tl.py xpl/explainer.py""".split()
# أصول عامة (مش من صور أي مريض): أشكال التصميم، الزرعة، الموسيقى، موديلات الوش
ASSETS = """tpl/g/design_oval.png tpl/g/design_square.png tpl/g/design_tri.png tpl/g/design_tri_upper.png tpl/g/chip.wav
assets/implant.png gen/music.mp3 face/face_landmarker.task face/selfie_multiclass.tflite""".split()

ROOT_EXPR = '(__import__("os").environ.get("DENTAL_ROOT") or __import__("os").path.dirname(__import__("os").path.dirname(__import__("os").path.abspath(__file__))))'
LIT = re.compile(r'(["\'])' + re.escape(S) + r'([^"\'\n]*)\1')
FONTS = re.compile(r'(["\'])/home/user/kochi-docs/studiomania/fonts/\1')


def rewrite(src):
    src = LIT.sub(lambda m: f'({ROOT_EXPR} + "/{m.group(2)}")', src)
    src = FONTS.sub('(__import__("os").environ.get("DENTAL_FONTS") or __import__("os").path.join(' + ROOT_EXPR + ', "..", "..", "fonts", ""))', src)
    # أي مسار جوه المنصة نفسها (backend/tools): نسبةً لجذر المحرك (studiomania/dental/engine ← studiomania)
    src = re.sub(r'(["\'])/home/user/kochi-docs/studiomania/([^"\'\n]*)\1', lambda m: f'({ROOT_EXPR} + "/../../{m.group(2)}")', src)
    # مفتاح Atlas: من متغير البيئة (المنصة بتديه لكل عميل) بدل الملف
    src = re.sub(r'open\(\(' + re.escape(ROOT_EXPR) + r' \+ "/\.atlas_key"\)\)\.read\(\)\.strip\(\)',
                 '(__import__("os").environ.get("ATLASCLOUD_API_KEY") or __import__("os").environ.get("ATLAS_CLOUD_API_KEY") or "")', src)
    return src


def main():
    for rel in CODE:
        out = DST + rel; os.makedirs(os.path.dirname(out), exist_ok=True)
        s = rewrite(open(S + rel, encoding="utf-8").read())
        left = [l for l in s.splitlines() if S in l or "/home/user/" in l]
        if left: print("⚠️ مسار ثابت لسه موجود في", rel, "\n   ", "\n    ".join(x.strip()[:140] for x in left[:5]))
        open(out, "w", encoding="utf-8").write(s); py_compile.compile(out, doraise=True)
    for rel in ASSETS:
        os.makedirs(os.path.dirname(DST + rel), exist_ok=True); shutil.copy2(S + rel, DST + rel)
    print("تم:", len(CODE), "ملف كود +", len(ASSETS), "أصل →", DST)


if __name__ == "__main__":
    main()
