import sys, json
sys.path.insert(0, "/tmp/claude-0/-home-user-kochi-docs/ccdf9718-7249-5c1f-aeb5-92c8b7e649b7/scratchpad/product")
from qa_video import frames, cuts
import motion as M
def run(path):
    fr = frames(path, fps=10, w=540); H = fr[0][1].shape[1] // 2
    fo = [(t, f[:, :H]) for t, f in fr]; frr = [(t, f[:, H:]) for t, f in fr]
    lo = [(t, __import__('cv2').resize(f, (270, int(270 * f.shape[0] / f.shape[1])))) for t, f in fo]
    lr = [(t, __import__('cv2').resize(f, (270, int(270 * f.shape[0] / f.shape[1])))) for t, f in frr]
    co, cr = cuts(lo), cuts(lr); T = fr[-1][0]
    po, pr = M.profile(lo, co), M.profile(lr, cr)
    r = {"Q5": M.motion_match(po, pr, T), "Q6": M.warp_issues(po, pr), "Q7": M.flash_issues(lo, co, lr, cr), "Q8": M.sharp_issues(fo[::5], frr[::5]), "Q6b": M.shear_issues([(t, f[30:]) for t, f in lo], [(t, f[30:]) for t, f in lr])}
    return r
for p in sys.argv[1:]:
    r = run(p); print("==", p); [print(" ", k, v) for k, v in r.items()]; sys.stdout.flush()
    json.dump(r, open("calib/" + p.replace("/", "_") + ".json", "w"), ensure_ascii=False)
