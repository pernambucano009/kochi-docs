"""للاختبار بس: ينقل عناصر الحالة الأولى المعتمدة لحالة الاختبار ويعلّمها معتمدة، علشان نختبر الريندر من فولدر حالة من غير تكلفة."""
import sys, os, shutil, glob
S = "/tmp/claude-0/-home-user-kochi-docs/ccdf9718-7249-5c1f-aeb5-92c8b7e649b7/scratchpad/"
sys.path.insert(0, S + "product")
from case import Case, APPROVED
c = Case(sys.argv[1]); E = c.d + "/elements/"; T = S + "tools/out/"; os.makedirs(E + "v", exist_ok=True)
files = ["after_portrait_v3.png", "after_portrait_hands.png", "after_portrait_pose_m.png", "profile_right.png", "angle_closed_0.png", "before_face_hi.png", "beach.png",
         "after_view_l.png", "after_view_r.png", "ap_teeth_v3.json", "ap_teeth_full.json", "smile_to_ap.npy", "retract_face.png", "retract_teeth_box.npy", "rcrop_teeth.png",
         "retract_h0.png", "retract_h1.png", "retract_c0.png", "retract_c1.png"]
for f in files:
    if os.path.exists(T + f) and not os.path.exists(E + f): shutil.copy(T + f, E + f)
for f in ("smile_open.png", "smile_lips.png"): shutil.copy(S + "tools/ms/" + f, E + "ms/" + f)
shutil.copy(S + "assets/selfie_img.png", E + "selfie_img.png")
V = S + "assets/v/"
for dst, src in {"after_live": "after_live_0", "after_blink": "after_blink_1", "after_fist": "after_fist_0", "before_live": "before_live_0", "before_turn": "turn_before3",
                 "after_selfie": "selfie3_lock", "after_mirror": "mirror_lock", "doctor_talk": "doctor2_lock"}.items():
    shutil.copy(V + src + ".mp4", E + f"v/{dst}.mp4")
for n in ["ms/smile_masks", "after_portrait_v3.png", "pose", "profile_right.png", "angle_closed_0.png", "after_views", "before_face_hi.png", "teeth_only", "ap_teeth", "retract",
          "selfie_img.png", "mirror_img.png", "doctor_img.png", "beach.png", "v/after_live.mp4", "v/after_blink.mp4", "v/after_fist.mp4", "v/before_live.mp4",
          "v/before_turn.mp4", "v/after_selfie.mp4", "v/after_mirror.mp4", "v/doctor_talk.mp4"]:
    c.set_el(n, status=APPROVED, note="اختبار: منقول من الحالة الأولى")
c.m["settings"]["city"] = "القاهرة"; c.m["patient"]["gender"] = "male"; c.save(); print("ok")
