"""يبني حالة تجريبية من صور case1 (نسخ مباشر بدل التصنيف بالموديل) عشان نختبر الأدوات من غير تكلفة."""
import sys, os, shutil, json
S = "/tmp/claude-0/-home-user-kochi-docs/ccdf9718-7249-5c1f-aeb5-92c8b7e649b7/scratchpad/"
sys.path.insert(0, S + "product")
from case import Case, SLOTS
d = sys.argv[1]; c = Case(d)
for k, (rel, _, _) in SLOTS.items():
    src = S + "case1/" + rel
    if os.path.exists(src):
        os.makedirs(os.path.dirname(c.canon(k)), exist_ok=True); shutil.copy(src, c.canon(k)); c.m["slots"][k] = {"file": rel, "test": True}
shutil.copy(S + "case1/after/smile_front.jpg", c.d + "/canon/after/smile_front.jpg")
for f in ("ai_before.png", "ai_after.png", "ai_smile.png", "lab_before.json", "lab_after.json", "lab_smile.json", "gm_before.png", "gm_after.png"):
    shutil.copy(S + "ana/" + f, c.d + "/ana/" + f)
c.m["patient"]["gender"] = "female"; c.save(); print(c.summary())
