#!/bin/bash
# طابور ريندر: كل سطر قالب
cd /tmp/claude-0/-home-user-kochi-docs/ccdf9718-7249-5c1f-aeb5-92c8b7e649b7/scratchpad/tpl
for n in "$@"; do
  timeout 7200 python3 T.py $n > out/R_$n.log 2>&1
  grep -E "DURATION" out/R_$n.log | tail -1 | sed "s/^/$n /" >> out/render_done.log || echo "$n FAIL" >> out/render_done.log
  grep -q DURATION out/R_$n.log || echo "$n FAIL $(grep -E 'Error' out/R_$n.log | tail -1)" >> out/render_done.log
done
